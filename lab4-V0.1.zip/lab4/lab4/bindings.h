#pragma once



/*
bindings:
- enum of user input actions (ex: up/down/shoot/etc.)
*/

// todo make generic
enum Binding { UP, DOWN, LEFT, RIGHT, SHOOT, MENU };

